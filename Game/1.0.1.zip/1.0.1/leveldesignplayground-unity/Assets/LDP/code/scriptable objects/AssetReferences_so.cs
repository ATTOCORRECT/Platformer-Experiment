﻿using UnityEngine;

namespace DevDev.LDP
{
    [CreateAssetMenu(menuName = Defines.assetMenu_Root + "AssetReferences")]
    public class AssetReferences_so : ScriptableObject
    {
        public AssetReferences data;
    }
}
