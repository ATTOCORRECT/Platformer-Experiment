﻿using UnityEngine;

namespace DevDev.LDP
{
    [CreateAssetMenu(menuName = Defines.assetMenu_Root + "Enemy Params")]
    public class Enemy_Params_so : ScriptableObject
    {
        public Enemy_Params data;
    }
}