﻿using UnityEngine;

namespace DevDev.LDP
{
    [RequireComponent(typeof(Collider2D))]
    public class Checkpoint_mono : MonoBehaviour
    {
        public Checkpoint data;
    }
}
