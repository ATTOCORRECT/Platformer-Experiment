﻿using UnityEngine;

namespace DevDev.LDP.UI
{
    public class Screen_HUD_mono : MonoBehaviour
    {
        public Screen_HUD data;
    }
}