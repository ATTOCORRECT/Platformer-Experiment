﻿using UnityEngine;

namespace DevDev.LDP
{
    public class Simulation_Environment_mono : MonoBehaviour
    {
        public Simulation_Environment data;        
    }
}
