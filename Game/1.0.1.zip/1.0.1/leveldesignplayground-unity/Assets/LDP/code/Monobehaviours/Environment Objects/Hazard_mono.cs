﻿using UnityEngine;

namespace DevDev.LDP
{
    [RequireComponent(typeof(Collider2D))]
    public class Hazard_mono : MonoBehaviour
    {
        public Hazard data;
    }
}