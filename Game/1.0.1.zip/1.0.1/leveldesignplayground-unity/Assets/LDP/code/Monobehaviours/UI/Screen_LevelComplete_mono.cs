﻿using UnityEngine;

namespace DevDev.LDP.UI
{
    public class Screen_LevelComplete_mono : MonoBehaviour
    {
        public Screen_LevelComplete data;
    }
}