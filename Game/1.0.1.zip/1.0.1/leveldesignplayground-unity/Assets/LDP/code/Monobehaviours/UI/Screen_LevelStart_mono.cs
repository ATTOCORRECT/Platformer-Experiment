﻿using UnityEngine;

namespace DevDev.LDP.UI
{
    public class Screen_LevelStart_mono : MonoBehaviour
    {
        public Screen_LevelStart data;
    }
}
