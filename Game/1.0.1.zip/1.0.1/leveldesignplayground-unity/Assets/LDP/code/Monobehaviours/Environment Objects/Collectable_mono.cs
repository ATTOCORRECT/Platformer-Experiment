﻿using UnityEngine;

namespace DevDev.LDP
{
    [RequireComponent(typeof(Collider2D))]
    public class Collectable_mono : MonoBehaviour
    {
        public Collectable data;
    }
}