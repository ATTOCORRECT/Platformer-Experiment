﻿using UnityEngine;

namespace DevDev.LDP
{
    [RequireComponent(typeof(Collider2D))]
    public class LevelExit_mono : MonoBehaviour
    {
        public LevelExit data;
    }
}