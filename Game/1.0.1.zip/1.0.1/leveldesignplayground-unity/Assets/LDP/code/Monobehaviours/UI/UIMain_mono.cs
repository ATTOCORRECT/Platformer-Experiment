﻿using UnityEngine;

namespace DevDev.LDP.UI
{
    public class UIMain_mono : MonoBehaviour
    {
        public UIMain data;
    }
}
