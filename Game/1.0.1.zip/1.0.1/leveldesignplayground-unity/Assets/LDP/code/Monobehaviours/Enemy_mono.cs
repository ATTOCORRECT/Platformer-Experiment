﻿using UnityEngine;

namespace DevDev.LDP
{
    public class Enemy_mono : MonoBehaviour
    {
        public Enemy data;
    }
}





















