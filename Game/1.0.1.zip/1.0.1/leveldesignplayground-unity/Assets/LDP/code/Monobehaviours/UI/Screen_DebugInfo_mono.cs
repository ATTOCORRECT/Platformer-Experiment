﻿using UnityEngine;

namespace DevDev.LDP.UI
{
    public class Screen_DebugInfo_mono : MonoBehaviour
    {
        public Screen_DebugInfo data;
    }
}
