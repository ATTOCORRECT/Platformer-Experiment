﻿using UnityEngine;

namespace DevDev.LDP.UI
{
    public class Screen_Pause_mono : MonoBehaviour
    {
        public Screen_Pause data;
    }
}
